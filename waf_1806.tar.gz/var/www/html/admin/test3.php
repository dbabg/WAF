<?php
  $txt='GET /public/read_np3.php?location=Sofia&submit=View+Result HTTP/1.1';

  $re1='.*?';	# Non-greedy match on filler
  $re2='((?:\\/[\\w\\.\\-]+)+)';	# Unix Path 1
  $re3='(\\?)';	# Any Single Character 1
  $re4='.*?';	# Non-greedy match on filler
  $re5='(?:[a-z][a-z]+)';	# Uninteresting: word
  $re6='.*?';	# Non-greedy match on filler
  $re7='(?:[a-z][a-z]+)';	# Uninteresting: word
  $re8='.*?';	# Non-greedy match on filler
  $re9='(?:[a-z][a-z]+)';	# Uninteresting: word
  $re10='.*?';	# Non-greedy match on filler
  $re11='(?:[a-z][a-z]+)';	# Uninteresting: word
  $re12='.*?';	# Non-greedy match on filler
  $re13='(?:[a-z][a-z]+)';	# Uninteresting: word
  $re14='.*?';	# Non-greedy match on filler
  $re15='((?:[a-z][a-z]+))';	# Word 1
  $re16='(\\/1\\.1)';	# Unix Path 2

  if ($c=preg_match_all ("/".$re1.$re2.$re3.$re4.$re5.$re6.$re7.$re8.$re9.$re10.$re11.$re12.$re13.$re14.$re15.$re16."/is", $txt, $matches))
  {
      $unixpath1=$matches[1][0];
      $c1=$matches[2][0];
      $word1=$matches[3][0];
      $unixpath2=$matches[4][0];
      print "($unixpath1) ($c1) ($word1) ($unixpath2) \n";
  }

?>
