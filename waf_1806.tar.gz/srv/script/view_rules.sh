#!/bin/bash

sed -n "/#rule 1/,//p" /etc/httpd/conf/httpd.conf  > /var/www/html/admin/rules.txt

cp /etc/httpd/conf/httpd.conf /var/www/html/admin/rules1.txt
chmod o+w /var/www/html/admin/rules1.txt
cat /var/www/html/admin/rules.txt
