#!/bin/bash

file1=/var/www/html/admin/rules1.txt
file2=/etc/httpd/conf/httpd.conf
cp /etc/httpd/conf/httpd.conf /etc/httpd/conf/httpd.conf.bkp.`date +"%Y-%m-%d %T"`
cp /var/www/html/admin/rules1.txt /etc/httpd/conf/httpd.conf
