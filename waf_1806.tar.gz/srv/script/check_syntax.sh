#!/bin/bash

/usr/sbin/apachectl configtest 
